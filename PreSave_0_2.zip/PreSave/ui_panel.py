import bpy

class PresetManagerPanel(bpy.types.Panel):
    bl_label = "Preset Manager"
    bl_idname = "VIEW3D_PT_preset_manager"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Preset Manager'

    def draw(self, context):
        layout = self.layout
        layout.label(text="Select a preset category below:")

class PresetManagerPanelTransform(bpy.types.Panel):
    bl_label = "Transform Presets"
    bl_parent_id = "VIEW3D_PT_preset_manager"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Preset Manager'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        obj = context.active_object

        layout.prop(scene, "save_location")
        layout.prop(scene, "save_rotation")
        layout.prop(scene, "save_scale")
        layout.prop(scene, "save_full_animation", text="Save Full Animation")

        save_enabled = obj and (scene.save_location or scene.save_rotation or scene.save_scale)

        row = layout.row()
        row.enabled = save_enabled
        row.operator("export_presets.save_transform", text="Save Transform Preset", icon="EXPORT")

        row = layout.row()
        row.operator("import_presets.apply_transform", text="Apply Transform Preset", icon="IMPORT")

class PresetManagerPanelModifiers(bpy.types.Panel):
    bl_label = "Modifier Presets"
    bl_parent_id = "VIEW3D_PT_preset_manager"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Preset Manager'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        obj = context.active_object
        save_enabled = obj is not None and len(obj.modifiers) > 0

        row = layout.row()
        row.enabled = save_enabled
        row.operator("export_presets.save_modifier", text="Save Modifier Preset", icon="EXPORT")

        row = layout.row()
        row.operator("import_presets.apply_modifier", text="Apply Modifier Preset", icon="IMPORT")
