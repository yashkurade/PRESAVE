import bpy

class PresetManagerPanel(bpy.types.Panel):
    bl_label = "Preset Manager"
    bl_idname = "VIEW3D_PT_preset_manager"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Preset Manager'

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        obj = context.active_object

        layout.label(text="Transform Presets")
        layout.prop(scene, "save_location")
        layout.prop(scene, "save_rotation")
        layout.prop(scene, "save_scale")
        layout.prop(scene, "save_full_animation", text="Save Full Animation")

        save_enabled = obj and (scene.save_location or scene.save_rotation or scene.save_scale)

        row = layout.row()
        row.enabled = save_enabled
        row.operator("export_presets.save_transform", text="Save Transform Preset", icon="EXPORT")

        row = layout.row()
        row.operator("import_presets.apply_transform", text="Apply Transform Preset", icon="IMPORT")

